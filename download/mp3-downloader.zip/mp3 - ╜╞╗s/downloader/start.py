import yt_dlp
import os
import re

# 設定下載目標資料夾
download_folder = './temp'
output_folder = '../output'

# 建立目標資料夾（如果不存在）
os.makedirs(download_folder, exist_ok=True)
os.makedirs(output_folder, exist_ok=True)

def download_and_convert(url):
    ydl_opts = {
        'outtmpl': os.path.join(download_folder, '%(title)s.%(ext)s'),
        'format': 'bestaudio[ext=m4a]',
        'concurrent_fragments': 16,
        'force_ipv4': True,
        'throttled_rate': '10000K',
        'continue_dl': True,
        'retries': 3,
        'fixup': 'warn'
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        title = info['title']
        input_file = os.path.join(download_folder, f"{title}.m4a")
        output_file = os.path.join(output_folder, f"{title}.mp3")
        os.system(f'ffmpeg -i "{input_file}" -b:a 320k -c:a libmp3lame -q:a 0 -abr 1 "{output_file}"')

with open('../input.txt', 'r') as f:
    for line in f.readlines():
        line = line.strip()
        line = re.sub(r'&list=[^&]+', '', line)
        
        # 先提取播放清單中的所有影片連結
        ydl_opts = {
            'quiet': True,
            'extract_flat': True,
            'force_generic_extractor': True
        }

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            result = ydl.extract_info(line, download=False)
            if 'entries' in result:
                video_urls = [entry['url'] for entry in result['entries']]
            else:
                video_urls = [line]
        
        # 逐一下載並轉換每個影片的音訊
        for video_url in video_urls:
            download_and_convert(video_url)
            print(f"Downloaded and converted: {video_url}")

# 清理下載資料夾
os.system(f'rmdir /s /q {download_folder}')
