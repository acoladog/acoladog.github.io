import yt_dlp
import os
import re
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from threading import Thread
import configparser
import tempfile  # 用于创建临时目录
import shutil  # 用于删除临时目录
import subprocess

# 初始化全局变量
is_downloading = False
processed_urls = set()
config_file = 'config.ini'  # 配置文件路径

# 加载配置
def load_config():
    config = configparser.ConfigParser()
    config.read(config_file)
    
    if config.has_section('Paths'):
        input_path = config.get('Paths', 'input', fallback="")
        output_path = config.get('Paths', 'output', fallback="")
        input_entry.insert(0, input_path)
        output_entry.insert(0, output_path)

# 保存配置
def save_config(input_path, output_path):
    config = configparser.ConfigParser()
    config['Paths'] = {
        'input': input_path,
        'output': output_path
    }
    
    with open(config_file, 'w') as configfile:
        config.write(configfile)

# 从播放列表提取视频URL
def extract_urls_from_playlist(url):
    try:
        ydl_opts = {
            'quiet': True,
            'extract_flat': True,
            'force_generic_extractor': True,
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if 'entries' in info:
                return [entry['url'] for entry in info['entries']]
    except Exception as e:
        log_text.insert(tk.END, f"Failed to extract URLs from: {url}\nError: {str(e)}\n")
        return []

# 下载和转换音频
def download_and_convert(url, download_folder, output_folder, total_videos, video_num):
    global is_downloading
    try:
        # 创建临时目录用于存放 m4a 文件
        with tempfile.TemporaryDirectory() as temp_dir:
            ydl_opts = {
                'outtmpl': os.path.join(temp_dir, '%(title)s.%(ext)s'),
                'format': 'bestaudio[ext=m4a]',
                'concurrent_fragments': 16,
                'force_ipv4': True,
                'throttled_rate': '10000K',
                'continue_dl': True,
                'retries': 3,
                'fixup': 'warn'
            }

            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                title = info['title']
                input_file = os.path.join(temp_dir, f"{title}.m4a")
                output_file = os.path.join(output_folder, f"{title}.mp3")
                subprocess.run(['ffmpeg', '-i', input_file, '-b:a', '320k', '-c:a', 'libmp3lame', '-q:a', '0', '-abr', '1', '-n', output_file], 
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)

            # 如果没有抛出异常，则更新日志和进度条
            log_text.insert(tk.END, f"Downloaded and converted: {url}\n")
            progress_var.set((video_num + 1) / total_videos * 100)
            progress_bar.update()

    except Exception as e:
        # 记录简洁的错误消息
        log_text.insert(tk.END, f"Failed to download or convert: {url}\n")
        with open('../fail.txt', 'a') as fail_file:
            fail_file.write(f"{url}\n")

def download_thread(urls, download_folder, output_folder):
    global is_downloading
    total_videos = len(urls)
    for video_num, url in enumerate(urls):
        if not is_downloading:
            break
        if url not in processed_urls:
            # 调用下载和转换函数
            download_and_convert(url, download_folder, output_folder, total_videos, video_num)
            if url in processed_urls:
                log_text.insert(tk.END, f"Skipped (duplicate): {url}\n")
        else:
            log_text.insert(tk.END, f"Skipped (duplicate): {url}\n")
    log_text.insert(tk.END, "Download finished.\n")
    is_downloading = False

# 开始下载
def start_download():
    global is_downloading
    if is_downloading:
        messagebox.showwarning("Warning", "Download is already in progress!")
        return
    
    input_file = input_entry.get().strip()
    if not input_file or not os.path.exists(input_file):
        messagebox.showerror("Error", "Invalid input file path!")
        return
    
    # 提取下载和输出文件夹路径
    download_folder = os.path.dirname(input_file)  # 假设输入文件目录是下载文件夹
    output_folder = output_entry.get().strip()
    if not output_folder or not os.path.exists(output_folder):
        messagebox.showerror("Error", "Invalid output folder!")
        return
    
    # 保存输入和输出位置到配置文件
    save_config(input_file, output_folder)
    
    is_downloading = True
    log_text.insert(tk.END, "Starting download...\n")
    
    urls = []
    with open(input_file, 'r') as f:
        for line in f:
            url = line.strip()
            if url:
                if 'playlist' in url:
                    urls.extend(extract_urls_from_playlist(url))
                else:
                    urls.append(url)
    
    urls = [re.sub(r'&list=[^&]+', '', url) for url in urls]
    
    # 重置进度条
    progress_var.set(0)
    progress_bar.update()

    # 启动下载线程
    Thread(target=download_thread, args=(urls, download_folder, output_folder)).start()

# 选择输入文件
def choose_input_file():
    input_file = filedialog.askopenfilename()
    if input_file:
        input_entry.delete(0, tk.END)
        input_entry.insert(0, input_file)
        # 保存新的输入文件位置到配置文件
        save_config(input_file, output_entry.get().strip())

# 选择输出文件夹
def choose_output_folder():
    output_folder = filedialog.askdirectory()
    if output_folder:
        output_entry.delete(0, tk.END)
        output_entry.insert(0, output_folder)
        # 保存新的输出文件夹位置到配置文件
        save_config(input_entry.get().strip(), output_folder)

# 构建UI界面
root = tk.Tk()
root.title("MP3 Downloader")

# 输入文件
tk.Label(root, text="Input:").grid(row=0, column=0, padx=10, pady=5)
input_entry = tk.Entry(root, width=50)
input_entry.grid(row=0, column=1, padx=10, pady=5)
tk.Button(root, text="Browse", command=choose_input_file).grid(row=0, column=2, padx=10, pady=5)

# 输出文件夹
tk.Label(root, text="Output:").grid(row=1, column=0, padx=10, pady=5)
output_entry = tk.Entry(root, width=50)
output_entry.grid(row=1, column=1, padx=10, pady=5)
tk.Button(root, text="Browse", command=choose_output_folder).grid(row=1, column=2, padx=10, pady=5)

# 开始按钮
tk.Button(root, text="Start", command=start_download).grid(row=3, column=0, padx=10, pady=10)

# 进度条
progress_var = tk.DoubleVar()
progress_bar = ttk.Progressbar(root, orient="horizontal", length=400, mode="determinate", variable=progress_var)
progress_bar.grid(row=3, column=0, columnspan=3, padx=10, pady=10)

# 日志区域
log_text = tk.Text(root, height=10, width=70)
log_text.grid(row=5, column=0, columnspan=3, padx=10, pady=10)

# 加载配置文件
load_config()

root.mainloop()
