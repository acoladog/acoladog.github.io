import yt_dlp
import os
import re

with open('..\input.txt', 'r') as f:
    for line in f.readlines():
        line = line.strip()
        line = re.sub(r'&list=[^&]+', '', line)
        ydl_opts = {
            'outtmpl': os.path.join('./temp', '%(title)s.%(ext)s'),  # Use os.path.join for better path handling
            'format': 'bestaudio[ext=m4a]',              'concurrent_fragments': 16,
            'force_ipv4': True,
            'throttled_rate': '10000K',
            'continue_dl': True,
            'retries': 3,
            'fixup': 'warn'
        }

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([line])

        os.system(f'ffmpeg -i ./temp/"{yt_dlp.YoutubeDL(ydl_opts).extract_info(line, download=False)["title"]}.m4a" -b:a 320k -c:a libmp3lame -q:a 0 -abr 1 ../output/"{yt_dlp.YoutubeDL(ydl_opts).extract_info(line, download=False)["title"]}.mp3"')
        os.system("rmdir /s /q temp")

        print(f"Downloaded: {line}")  # Print a success message
