import yt_dlp
import re

with open('..\input.txt', 'r') as f:
    for line in f.readlines():
        line = line.strip()
        
        # Remove 'list=' from the line
        line = re.sub(r'&list=[^&]+', '', line)
        
        ydl_opts = {
            'outtmpl': '..\output\%(title)s.%(ext)s',
            'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]',
            'concurrent_fragmets': 16,
            'force-ipv4': True,
            'throttled_rate': '10000K',
            'continue_dl': True,
            'retries': 3,
            'fixup': 'warn'
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([line])
        print(line)
