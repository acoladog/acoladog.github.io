#include <bits/stdc++.h>
#include <thread>
#include <windows.h>

using namespace std;

int err = 0;

int tit() {
    ifstream file("./temp/title.json.info.json");  // �}���ɮ�
    ofstream outputFile("./temp/title.txt");  // �إ߿�X�ɮ�
    char ch;
    string title;
    bool readingtitle = false;
    int a = 0;
    if (!file.is_open()) {
        cerr << "Unable to open input file." << endl;
        return 1;
    }

    if (!outputFile.is_open()) {
        cerr << "Unable to open output file." << endl;
        file.close();
        return 1;
    }

    while (file.get(ch)) {
        if (ch == '"') {
            a++;
        }
        if (a == 8) readingtitle = false;
        if (readingtitle) {
            if (ch != '\\' && ch != '/') title += ch;
        }
        if (a == 7) {
            readingtitle = true;
        }
    }
    outputFile << title << endl;

    file.close();
    outputFile.close();
    return 0;
}

int test(string line) {
    int a = system("dir .\\temp\\temp.mp4 >nul 2>&1");
    int b = system("dir .\\temp\\temp.m4a >nul 2>&1");
    int c = system("dir .\\temp\\title.txt >nul 2>&1");
    string ercode = " Error code : ";
    if (a) { ercode += "mp4.err "; err++; }
    if (b) { ercode += "m4a.err "; err++; }
    if (c) { ercode += "title.err "; err++; }
    if (a || b || c) {
        time_t now = time(0);
        char* dtChar = ctime(&now);
        string dt(dtChar); // �ഫ�� std::string
        dt.resize(dt.size() - 1); // ��������Ÿ�

        ifstream ifs("..\\fail.txt");
        string content((istreambuf_iterator<char>(ifs)), (istreambuf_iterator<char>()));
        ifs.close();

        ofstream cant("..\\fail.txt", ios::trunc);
        cant << dt << " " << line << ercode << endl; // �g�J�s�����
        cant << content; // �N�ª���Ƽg�^�ɮ�
        cant.close();
    }
    return 1;
}

int main() {
    system("chcp 65001");
    system("update.bat");
    ifstream inputFile("..\\input.txt");  // ���}��J���
    string line;

    if (!inputFile.is_open()) {
        cerr << "Unable to open input file\n";
        return 1;
    }

    // �v��Ū�����
    while (getline(inputFile, line)) {
        // �T�O�s���榡���T�]�u�� YouTube �v���� ID�^
        size_t pos = line.find("watch?v=");
        if (pos != string::npos) {
            line = line.substr(pos + 8, 11);
        } else {
            cerr << "Invalid YouTube link format: " << line << endl;
            continue;
        }

        // ����yt-dlp�R�O
        string ytDlpCommandVideo = "yt-dlp https://www.youtube.com/watch?v=" + line + " -o \"./temp/temp.%(ext)s\" -f bestvideo[ext=mp4] --concurrent-fragments 16 --force-ipv4 --throttled-rate 100K --continue --retries 3";
        system(ytDlpCommandVideo.c_str());

        string ytDlpCommandAudio = "yt-dlp https://www.youtube.com/watch?v=" + line + " -o \"./temp/temp.%(ext)s\" -f bestaudio[ext=m4a] --concurrent-fragments 16 --force-ipv4 --throttled-rate 100K --continue --retries 3";
        system(ytDlpCommandAudio.c_str());

        // ����yt-dlp�R�O�ӤU��JSON�H��
        string ytDlpCommandJson = "yt-dlp --write-info-json https://www.youtube.com/watch?v=" + line + " -o \"./temp/title.json\"";
        system(ytDlpCommandJson.c_str());

        // �^��title
        tit();

        // �����̭��O�_�t��temp.mp4��temp.m4a�٦�title.txt 
        test(line);

        string ffmpegCommand = "ffmpeg -i \"./temp/temp.mp4\" -i \"./temp/temp.m4a\" -c:v copy -c:a copy \"..\\output\\final.mp4\"";
        system(ffmpegCommand.c_str());

        // ���ɦW
        system("rename.bat");
        system("rmdir /s /q temp");
    }

    if (err) {
        string text = to_string(err) + " of the mp4 can't download";
        string text1;
        if (err == 1)
            text1 = "the video's link has been stored in the \"fail.txt\"";
        else if (err > 1)
            text1 = "the videos' links have been stored in the \"fail.txt\"";

        MessageBox(NULL, text.c_str(), "worrying", MB_OK | MB_ICONINFORMATION);
        MessageBox(NULL, text1.c_str(), "worrying", MB_OK | MB_ICONINFORMATION);
    }

    inputFile.close();
    return 0;
}

