#!/usr/bin/env python3
import os
import urllib.request
import zipfile
import tempfile
import shutil
import subprocess
import time

# 定義不替換的安全檔案（以 ZIP 解壓後的相對路徑為準）
SAFE_FILES = {
    os.path.normpath("files/config.ini"),
    os.path.normpath("files/input.txt"),
    os.path.normpath("files/log.txt"),
    os.path.normpath("files/language/config.ini"),
    os.path.normpath("files/update.py"),
}

def download_zip(url, dest_path):
    print(f"下載更新檔案：{url}")
    urllib.request.urlretrieve(url, dest_path)
    print("下載完成！")

def update_files():
    url = "https://marmotadog.github.io/download/MP34D.zip"
    with tempfile.TemporaryDirectory() as tmpdirname:
        zip_path = os.path.join(tmpdirname, "MP34D.zip")
        download_zip(url, zip_path)
        # 解壓縮 ZIP 到暫存資料夾
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(tmpdirname)
        print("開始更新檔案...")
        
        # 定義目標目錄：update.py 所在目錄的父層的上一層，即 ../../
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        
        # 遍歷解壓縮後的所有檔案
        for root, dirs, files in os.walk(tmpdirname):
            for file in files:
                full_path = os.path.join(root, file)
                # 取得相對於暫存資料夾的路徑
                rel_path = os.path.relpath(full_path, tmpdirname)
                norm_rel_path = os.path.normpath(rel_path)
                
                # 略過檔名為 MP34D.zip 的檔案
                if os.path.basename(norm_rel_path) == "MP34D.zip":
                    print(f"略過不需要的檔案: {norm_rel_path}")
                    continue
                
                # 若檔案位於 files/MP34D/ 之下，則移除 MP34D 部分，讓檔案合併到 files 中
                prefix = os.path.join("files", "MP34D")
                if norm_rel_path.startswith(prefix + os.sep):
                    new_rel_path = os.path.join("files", norm_rel_path[len(prefix + os.sep):])
                    print(f"調整路徑: {norm_rel_path} -> {new_rel_path}")
                    norm_rel_path = new_rel_path

                # 若該檔案屬於不替換清單，則跳過更新
                if norm_rel_path in SAFE_FILES:
                    print(f"略過保留檔案: {norm_rel_path}")
                    continue

                # 建構目標檔案路徑：使用 base_dir（即 ../../）
                dest_path = os.path.join(base_dir, norm_rel_path)
                dest_dir = os.path.dirname(dest_path)
                if not os.path.exists(dest_dir):
                    os.makedirs(dest_dir, exist_ok=True)
                shutil.copy2(full_path, dest_path)
                print(f"更新: {norm_rel_path}")
        print("檔案更新完成！")

if __name__ == "__main__":
    try:
        # 更新前先關閉主程式 downloader.exe
        print("嘗試先關閉主程式 downloader.exe...")
        subprocess.call(["taskkill", "/IM", "downloader.exe", "/F"])
        time.sleep(1)  # 等待程式關閉
        
        # 執行更新程序
        update_files()
        
        # 更新完成後，啟動 ../downloader.exe（update.py 所在目錄的上一層）
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        downloader_path = os.path.join(base_dir, "downloader.exe")
        print(f"啟動主程式: {downloader_path}")
        subprocess.Popen([downloader_path])
        print("更新流程完成，主程式已重新啟動。")
    except Exception as e:
        print("更新過程中發生錯誤:", e)
