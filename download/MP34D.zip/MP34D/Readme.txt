start.bat會開啟./downloader/downloader.exe

編輯你的input
youtube的連結放到裡面
例如:
https://www.youtube.com/watch?v=***********
https://www.youtube.com/watch?v=***********
https://www.youtube.com/watch?v=***********

@它會自動儲存@

！請注意！
檔名不可包含 \ / : * ? " < > |，所以下載器會自動刪除該字符
檔名不可包含 \ / : * ? " < > |，所以下載器會自動刪除該字符
檔名不可包含 \ / : * ? " < > |，所以下載器會自動刪除該字符
很重要，所以講三遍

支援播放清單
支援bilibili、youtube
下載好的音檔就會在output中出現(預設為../output資料夾)
如果沒下載完成，在本目錄下會看見一個fail.txt，或在About裡可以查看

所有下載器的事件都會存入log.txt，檔案會慢慢變大，在About裡可以開啟或刪除檔案

按照網速的不同，下載速度也會不盡相同喔

(如有任何問題，請私 coladog1112@gmail.com 感謝)
